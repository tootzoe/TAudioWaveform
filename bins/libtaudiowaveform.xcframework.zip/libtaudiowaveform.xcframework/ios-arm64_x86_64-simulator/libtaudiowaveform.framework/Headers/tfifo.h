//
//  tfifo.h
//  RecWaveform
//
//  Created by thor on 27/3/24
//  
//
//  Email: toot@tootzoe.com  Tel: +855 69325538 
//
//

  
#ifndef tfifo_h
#define tfifo_h

#include <stdio.h>


int fifoReadWav(const char *pathname );
void fifoReadWavExit(void);
 //

//belowing is from swift
extern void fifoWavByteArrArrived(const double *dat , int32_t len  );

 
#endif /* tfifo_h */
