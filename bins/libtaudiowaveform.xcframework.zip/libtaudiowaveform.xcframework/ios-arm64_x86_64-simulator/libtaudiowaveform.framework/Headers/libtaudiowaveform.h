//
//  libtaudiowaveform.h
//  libtaudiowaveform
//
//  Created by thor on 31/3/24
//  
//
//  Email: toot@tootzoe.com  Tel: +855 69325538 
//
//

 

#import <Foundation/Foundation.h>

//! Project version number for libtaudiowaveform.
FOUNDATION_EXPORT double libtaudiowaveformVersionNumber;

//! Project version string for libtaudiowaveform.
FOUNDATION_EXPORT const unsigned char libtaudiowaveformVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <libtaudiowaveform/PublicHeader.h>


#import <libtaudiowaveform/tfifo.h>
#import <libtaudiowaveform/soxCoordinator.h>

 
 

// libtaudiowaveform/tfunctionsbridge.h





