//
//  soxCoordinator.h
//  SoxlibTest
//
//  Created by thor on 9/3/24
//  
//
//  Email: toot@tootzoe.com  Tel: +855 69325538 
//
//

 

#ifndef soxCoordinator_h
#define soxCoordinator_h

#include <stdio.h>



 
long genWavformByFile ( const char * ,  double start_secs, double period ,  double * , int  );

long genWavform(const uint8_t* dat, int32_t len , double *outDat , int32_t  maxOutLen);
//
 


#endif /* soxCoordinator_h */
